#ifndef SSAGEPARUDERS_NATIVE_SURFACE_H
#define SSAGEPARUDERS_NATIVE_SURFACE_H

#include "Android_draw/draw.h"

extern int abs_ScreenX, abs_ScreenY;

#endif

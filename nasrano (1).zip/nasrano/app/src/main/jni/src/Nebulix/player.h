bool fast_fire;
void player() {
    uintptr_t _playermanager = 111180928;
	uint64_t playermanager = rpm<uint64_t>(rpm<uint64_t>(rpm<uint64_t>(rpm<uint64_t>(il2cpp_base + _playermanager) + 0x58) + 0xB8) + 0x0);
    uint64_t localPlayer = rpm<uint64_t>(playermanager + 0x70);
	
	
	uint64_t weaponrycontroller = rpm<uint64_t>(localPlayer + 0x68);
    uint64_t weaponcontroller = rpm<uint64_t>(weaponrycontroller + 0x98);
	
	if (fast_fire) {
		WriteSafe(weaponcontroller + 0xF0, 0);
	}
	
}

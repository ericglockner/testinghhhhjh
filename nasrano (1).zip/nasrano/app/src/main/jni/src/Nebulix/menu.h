
void RenderMenu() {
		ImGui::Checkbox("Fast Fire", &fast_fire);

    g_window = ImGui::GetCurrentWindow();
    ImGui::End();
}
